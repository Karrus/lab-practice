﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace BKS
{
    public partial class adminForm2 : Form

    {
        public static string connectString = "Provider = Microsoft.Jet.OLEDB.4.0;Data Source = БКС.mdb";
        private OleDbConnection Connection;
        public adminForm2()
        {
            InitializeComponent();
            Connection = new OleDbConnection(connectString);
            Connection.Open();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int kod = Convert.ToInt32(textBox1.Text);
            string departure = textBox2.Text;
            string seat_number = textBox3.Text;
            string FCs = textBox4.Text;
            string Passport = textBox5.Text;
            string query = "INSERT INTO Пассажиры ([Код пассажира], Вылет, [Номер места], ФИО, Паспорт) VALUES (" + kod + ",'" + departure +"','"+ seat_number +"','"+ FCs +"','"+ Passport +"')";                                 ;
            OleDbCommand Command = new OleDbCommand(query, Connection);
            Command.ExecuteNonQuery();
            MessageBox.Show("Данные Добавленны", "Внимание");
        }
    }
}
 