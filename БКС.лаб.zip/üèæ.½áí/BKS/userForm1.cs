﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BKS
{
    public partial class userForm1 : Form
    {
        public userForm1()
        {
            InitializeComponent();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void userForm1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "бКСDataSet.Пассажиры". При необходимости она может быть перемещена или удалена.
            this.пассажирыTableAdapter.Fill(this.бКСDataSet.Пассажиры);
            

        }

        

        private void button2_Click(object sender, EventArgs e)
        {
            new LoginForm1().Show();
        }
    }
}
