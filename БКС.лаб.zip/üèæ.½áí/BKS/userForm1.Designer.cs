﻿
namespace BKS
{
    partial class userForm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.кодПассажираDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.вылетDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номерМестаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.фИОDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.паспортDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.пассажирыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.бКСDataSet = new BKS.БКСDataSet();
            this.аэропортыНазначенияBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.аэропорты_назначенияTableAdapter = new BKS.БКСDataSetTableAdapters.Аэропорты_назначенияTableAdapter();
            this.пассажирыTableAdapter = new BKS.БКСDataSetTableAdapters.ПассажирыTableAdapter();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.пассажирыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.бКСDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.аэропортыНазначенияBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(971, 102);
            this.panel1.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(337, 42);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(294, 58);
            this.label2.TabIndex = 1;
            this.label2.Text = "Пассажиры";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(217)))), ((int)(((byte)(217)))));
            this.label1.Location = new System.Drawing.Point(937, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "x";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gray;
            this.panel2.Controls.Add(this.dataGridView1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 102);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(971, 388);
            this.panel2.TabIndex = 1;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодПассажираDataGridViewTextBoxColumn,
            this.вылетDataGridViewTextBoxColumn,
            this.номерМестаDataGridViewTextBoxColumn,
            this.фИОDataGridViewTextBoxColumn,
            this.паспортDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.пассажирыBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(147, 32);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(729, 192);
            this.dataGridView1.TabIndex = 0;
            // 
            // кодПассажираDataGridViewTextBoxColumn
            // 
            this.кодПассажираDataGridViewTextBoxColumn.DataPropertyName = "Код пассажира";
            this.кодПассажираDataGridViewTextBoxColumn.HeaderText = "Код пассажира";
            this.кодПассажираDataGridViewTextBoxColumn.Name = "кодПассажираDataGridViewTextBoxColumn";
            // 
            // вылетDataGridViewTextBoxColumn
            // 
            this.вылетDataGridViewTextBoxColumn.DataPropertyName = "Вылет";
            this.вылетDataGridViewTextBoxColumn.HeaderText = "Вылет";
            this.вылетDataGridViewTextBoxColumn.Name = "вылетDataGridViewTextBoxColumn";
            // 
            // номерМестаDataGridViewTextBoxColumn
            // 
            this.номерМестаDataGridViewTextBoxColumn.DataPropertyName = "Номер места";
            this.номерМестаDataGridViewTextBoxColumn.HeaderText = "Номер места";
            this.номерМестаDataGridViewTextBoxColumn.Name = "номерМестаDataGridViewTextBoxColumn";
            // 
            // фИОDataGridViewTextBoxColumn
            // 
            this.фИОDataGridViewTextBoxColumn.DataPropertyName = "ФИО";
            this.фИОDataGridViewTextBoxColumn.HeaderText = "ФИО";
            this.фИОDataGridViewTextBoxColumn.Name = "фИОDataGridViewTextBoxColumn";
            // 
            // паспортDataGridViewTextBoxColumn
            // 
            this.паспортDataGridViewTextBoxColumn.DataPropertyName = "Паспорт";
            this.паспортDataGridViewTextBoxColumn.HeaderText = "Паспорт";
            this.паспортDataGridViewTextBoxColumn.Name = "паспортDataGridViewTextBoxColumn";
            // 
            // пассажирыBindingSource
            // 
            this.пассажирыBindingSource.DataMember = "Пассажиры";
            this.пассажирыBindingSource.DataSource = this.бКСDataSet;
            // 
            // бКСDataSet
            // 
            this.бКСDataSet.DataSetName = "БКСDataSet";
            this.бКСDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // аэропортыНазначенияBindingSource
            // 
            this.аэропортыНазначенияBindingSource.DataMember = "Аэропорты назначения";
            this.аэропортыНазначенияBindingSource.DataSource = this.бКСDataSet;
            // 
            // аэропорты_назначенияTableAdapter
            // 
            this.аэропорты_назначенияTableAdapter.ClearBeforeFill = true;
            // 
            // пассажирыTableAdapter
            // 
            this.пассажирыTableAdapter.ClearBeforeFill = true;
            // 
            // userForm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(971, 490);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "userForm1";
            this.Text = "userForm1";
            this.Load += new System.EventHandler(this.userForm1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.пассажирыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.бКСDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.аэропортыНазначенияBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private БКСDataSet бКСDataSet;
        private System.Windows.Forms.BindingSource аэропортыНазначенияBindingSource;
        private БКСDataSetTableAdapters.Аэропорты_назначенияTableAdapter аэропорты_назначенияTableAdapter;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.BindingSource пассажирыBindingSource;
        private БКСDataSetTableAdapters.ПассажирыTableAdapter пассажирыTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодПассажираDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn вылетDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерМестаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn фИОDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn паспортDataGridViewTextBoxColumn;
    }
}