﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;


namespace BKS
{

    public partial class adminForm1 : Form
    {
        public static string connectString = "Provider = Microsoft.Jet.OLEDB.4.0;Data Source = БКС.mdb";
        private OleDbConnection Connection;

        public adminForm1()
        {
            InitializeComponent();
            Connection = new OleDbConnection(connectString);
            Connection.Open();
        }

        private void adminForm1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "бКСDataSet.Пассажиры". При необходимости она может быть перемещена или удалена.
            this.пассажирыTableAdapter.Fill(this.бКСDataSet.Пассажиры);
            

        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       
            private void button2_Click(object sender, EventArgs e)
        {
            int kod = Convert.ToInt32(textBox2.Text);
            string query = "UPDATE Пассажиры SET Паспорт = '" + textBox3 + "'WHERE [Код пассажира] = " + kod;
            OleDbCommand Command = new OleDbCommand(query, Connection);
            Command.ExecuteNonQuery();
            MessageBox.Show("Данные изменены", "Внимание");
            this.пассажирыTableAdapter.Fill(this.бКСDataSet.Пассажиры);




        }

        private void adminForm1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Connection.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int kod = Convert.ToInt32(textBox1.Text);
            string query = "DELETE FROM Пассажиры WHERE [Код пассажира] = " + kod;
            OleDbCommand Command = new OleDbCommand(query, Connection);
            Command.ExecuteNonQuery();
            MessageBox.Show("Данные удалены","Внимание");
            this.пассажирыTableAdapter.Fill(this.бКСDataSet.Пассажиры);


        }

        private void button1_Click(object sender, EventArgs e)
        {
            adminForm2 f2 = new adminForm2();
            f2.Owner = this;
            f2.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.пассажирыTableAdapter.Fill(this.бКСDataSet.Пассажиры);

        }
    }
}
