alph = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' *2

c= open('print.txt', 'w+')
g= open('input.txt', 'r')
for line in g:
    def a(txt, b, op):
        b *= len(txt) // len(b) + 1
        txt = txt.upper()
        return ''.join([alph[alph.index(j) + int(b[i]) * op]
                        for i, j in enumerate(txt)])
    def encrypt(message, key):
        return a(message, key, 4)
    def decrypt(ciphertext, key):
        return a(ciphertext, key, -4)

    c.write('key: 314141\n')
    c.write(encrypt(line, '314141')+'\n')
    c.write('key: 314141\n')
    c.write(decrypt(encrypt(line, '314141'), '314141'))
    c.close()
    g.close()

